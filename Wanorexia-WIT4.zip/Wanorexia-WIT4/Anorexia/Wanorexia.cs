﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Anorexia
{

    //
    //
    //TODO: Find a way to change folder source and target
    //TODO: Find a way to filter for only files wanted--Can I split a name into a string list, find the file ext. and work 
    //from that??
    //TODO: Find a way to make folders for selected file types
    //TODO: MAKE UI PRETTIER-- It is god awful ugly
    //TODO: Find out how to make form window persistant until transfers are complete
    //Jesus that's a lot of work ^
    public partial class LAnorexia : Form
    {
        public static DirectoryInfo source = new DirectoryInfo(Directory.GetCurrentDirectory());
        public static string targ3 = Path.Combine(Directory.GetCurrentDirectory(), "A1-Purged"); //the A1 ensures that it sits on the top of the list
        //need a master count to know when to kill the app
        //need master count to allow me to alert the user when the app has finished:
        //
        //System.IO.Directory myDir = GetMyDirectoryForTheExample();
        //int count = myDir.GetFiles().Length;


        public LAnorexia()
        {
            InitializeComponent();
            lblDirectory.Text = Directory.GetCurrentDirectory();
        }
        //begin button handlers
        //this is the simple part
        private void BtnYes_Click(object sender, EventArgs e)
        {
            if (source.ToString() != @"C:/" || source.ToString() != @"c:/")
            {

                try
                {
                    Directory.CreateDirectory(Path.Combine(Directory.GetCurrentDirectory(), "A1-Purged"));
                    string targ = Path.Combine(Directory.GetCurrentDirectory(), "A1-Purged");
                    if (cbDelete.Checked == true)
                    {
                        MovePurge(source, targ);
                    }
                    else if (cbCopy.Checked == true)
                    {
                        CopyPurge(source, targ);
                    }
                    else
                    {
                        MovePurge(source, targ);
                    }
                }
                catch (System.IO.IOException)
                {
                    string targ = Path.Combine(Directory.GetCurrentDirectory(), "A1-Purged");
                    if (cbDelete.Checked == true)
                    {
                        MovePurge(source, targ);
                    }
                    else if (cbCopy.Checked == true)
                    {
                        CopyPurge(source, targ);
                    }
                    else
                    {
                        MovePurge(source, targ);
                    }
                }
            }
            else
            {
                MessageBox.Show("If you run app in the root directory, you could perminately damage this computer!!!");
            }
        }
        

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //end button handlers

        //begin other methods
        protected override bool ProcessDialogKey(Keys keyData) //tie escape to exit
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

        //
        //foreach (DirectoryInfo dir in source.GetDirectories("*"))
        //{
        //   foreach (FileInfo file in source.GetFiles())
        //      if (file.Name != "Anorexia.exe")
        //     {
        //        file.CopyTo(Path.Combine(target.FullName, file.Name));
        //    }
        //   }
        //}

        public void MovePurge(System.IO.DirectoryInfo root, string target)
        {
            int count = root.GetFiles().Length;
            System.IO.FileInfo[] files = null;
            System.IO.DirectoryInfo[] subDirs = null;
            List<string> kiddies = new List<string>();
            // First, process all the files directly under this folder 
            try
            {
                files = root.GetFiles("*.*");
                pbar.Maximum = root.GetFiles().Length;
                pbar.Step = 1;
            }
            // This is thrown if even one of the files requires permissions greater
            // than the application provides.
            catch (UnauthorizedAccessException e)
            {
                // This code just writes out the message and continues to recurse.
                // You may decide to do something different here. For example, you
                // can try to elevate your privileges and access the file again.
                MessageBox.Show("You don't have the privileges");
                MessageBox.Show("Error: " + e);
            }

            catch (System.IO.DirectoryNotFoundException e)
            {
                MessageBox.Show(e.Message);
            }
            int fil_cont = root.GetFiles().Length;
            if (files != null)
            {
                foreach (System.IO.FileInfo fi in files)
                {
                    // In this example, we only access the existing FileInfo object. If we
                    // want to open, delete or modify the file, then
                    // a try-catch block is required here to handle the case
                    // where the file has been deleted since the call to TraverseTree().
                    try
                    {
                        if (Path.Combine(Directory.GetCurrentDirectory(), fi.Name) != Path.Combine(Directory.GetCurrentDirectory(), "Anorexia.exe"))
                        {
                            lblBarAction.Text = "Moving: " + fi.Name + "to target.";
                            fi.MoveTo(Path.Combine(target, fi.Name));
                            pbar.PerformStep();
                        }
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show("Can't copy this file: " + fi.Name + "\n" + "\n" + "Exception: " + ex);
                    }
                }
                // Now find all the subdirectories under this directory.
                subDirs = root.GetDirectories();
                foreach (System.IO.DirectoryInfo dirInfo in subDirs)
                {
                    // Resursive call for each subdirectory.
                    lblBarAction.Text = ("The files have been purged");
                    MovePurge(dirInfo, target);
                }
            }
        } //Moves files to A1-Purged leaves directory structure intact

        public void CopyPurge(System.IO.DirectoryInfo root, string target) //
        {
            int count = root.GetFiles().Length;
            System.IO.FileInfo[] files = null;
            System.IO.DirectoryInfo[] subDirs = null;
            List<string> kiddies = new List<string>();
            // First, process all the files directly under this folder 
            try
            {
                files = root.GetFiles("*.*");
                pbar.Maximum = root.GetFiles().Length;
                pbar.Step = 1;
            }
            // This is thrown if even one of the files requires permissions greater
            // than the application provides.
            catch (UnauthorizedAccessException e)
            {
                // This code just writes out the message and continues to recurse.
                // You may decide to do something different here. For example, you
                // can try to elevate your privileges and access the file again.
                MessageBox.Show("You don't have the privileges");
                MessageBox.Show("Error: " + e);
            }

            catch (System.IO.DirectoryNotFoundException e)
            {
                MessageBox.Show(e.Message);
            }
            int fil_cont = root.GetFiles().Length;
            if (files != null)
            {
                foreach (System.IO.FileInfo fi in files)
                {
                    // In this example, we only access the existing FileInfo object. If we
                    // want to open, delete or modify the file, then
                    // a try-catch block is required here to handle the case
                    // where the file has been deleted since the call to TraverseTree().
                    try
                    {
                        if (Path.Combine(Directory.GetCurrentDirectory(), fi.Name) != Path.Combine(Directory.GetCurrentDirectory(), "Anorexia.exe"))
                        {
                            lblBarAction.Text = "Moving: " + fi.Name + "To target.";
                            fi.CopyTo(Path.Combine(target, fi.Name));
                            pbar.PerformStep();
                        }
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show("Can't copy this file: " + fi.Name + "\n" + "\n" + "Exception: " + ex);
                    }
                }
                // Now find all the subdirectories under this directory.
                subDirs = root.GetDirectories();
                foreach (System.IO.DirectoryInfo dirInfo in subDirs)
                {
                    // Resursive call for each subdirectory.
                    CopyPurge(dirInfo, target);
                }
            }
        }
    }
}
//THis is a production of EffortlessTurtle
//EffortlessTurtle == Tyler Shrouder
//Dev credit to Raymond Tresner also.        
    

