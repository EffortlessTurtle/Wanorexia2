﻿namespace Anorexia
{
    partial class LAnorexia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnYes = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.lblNNDumpTo = new System.Windows.Forms.Label();
            this.lblDirectory = new System.Windows.Forms.Label();
            this.pbar = new System.Windows.Forms.ProgressBar();
            this.lblBarAction = new System.Windows.Forms.Label();
            this.cbDelete = new System.Windows.Forms.CheckBox();
            this.cbCopy = new System.Windows.Forms.CheckBox();
            this.lblErToss = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnExit2 = new System.Windows.Forms.Button();
            this.btnGO = new System.Windows.Forms.Button();
            this.lblTarg1 = new System.Windows.Forms.Label();
            this.lblSrc = new System.Windows.Forms.Label();
            this.btnTarget = new System.Windows.Forms.Button();
            this.btnSource = new System.Windows.Forms.Button();
            this.lblNNSourceFol = new System.Windows.Forms.Label();
            this.lblNNTarget = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pbar2 = new System.Windows.Forms.ProgressBar();
            this.lblActTar = new System.Windows.Forms.Label();
            this.lblErToss2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RBMove = new System.Windows.Forms.RadioButton();
            this.RBCopy = new System.Windows.Forms.RadioButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnYes
            // 
            this.BtnYes.BackColor = System.Drawing.Color.Lime;
            this.BtnYes.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnYes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnYes.Location = new System.Drawing.Point(4, 84);
            this.BtnYes.Name = "BtnYes";
            this.BtnYes.Size = new System.Drawing.Size(95, 39);
            this.BtnYes.TabIndex = 0;
            this.BtnYes.Text = "PURGE!";
            this.BtnYes.UseVisualStyleBackColor = false;
            this.BtnYes.Click += new System.EventHandler(this.BtnYes_Click);
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNo.Location = new System.Drawing.Point(543, 84);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(95, 39);
            this.btnNo.TabIndex = 1;
            this.btnNo.Text = "Or Not";
            this.btnNo.UseVisualStyleBackColor = false;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // lblNNDumpTo
            // 
            this.lblNNDumpTo.AutoSize = true;
            this.lblNNDumpTo.Location = new System.Drawing.Point(1, 5);
            this.lblNNDumpTo.Name = "lblNNDumpTo";
            this.lblNNDumpTo.Size = new System.Drawing.Size(464, 17);
            this.lblNNDumpTo.TabIndex = 3;
            this.lblNNDumpTo.Text = "Consolidate files in child directories to \'A1-Purged\' from Parent directory:";
            // 
            // lblDirectory
            // 
            this.lblDirectory.AutoSize = true;
            this.lblDirectory.Location = new System.Drawing.Point(1, 42);
            this.lblDirectory.Name = "lblDirectory";
            this.lblDirectory.Size = new System.Drawing.Size(0, 17);
            this.lblDirectory.TabIndex = 4;
            // 
            // pbar
            // 
            this.pbar.ForeColor = System.Drawing.Color.Black;
            this.pbar.Location = new System.Drawing.Point(4, 175);
            this.pbar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbar.Name = "pbar";
            this.pbar.Size = new System.Drawing.Size(634, 29);
            this.pbar.Step = 1;
            this.pbar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbar.TabIndex = 5;
            // 
            // lblBarAction
            // 
            this.lblBarAction.AutoSize = true;
            this.lblBarAction.Location = new System.Drawing.Point(4, 141);
            this.lblBarAction.Name = "lblBarAction";
            this.lblBarAction.Size = new System.Drawing.Size(0, 17);
            this.lblBarAction.TabIndex = 6;
            // 
            // cbDelete
            // 
            this.cbDelete.AutoSize = true;
            this.cbDelete.Checked = true;
            this.cbDelete.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbDelete.Location = new System.Drawing.Point(5, 270);
            this.cbDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbDelete.Name = "cbDelete";
            this.cbDelete.Size = new System.Drawing.Size(194, 21);
            this.cbDelete.TabIndex = 7;
            this.cbDelete.Text = "Move files to target Folder";
            this.cbDelete.UseVisualStyleBackColor = true;
            this.cbDelete.CheckedChanged += new System.EventHandler(this.cbDelete_CheckedChanged);
            // 
            // cbCopy
            // 
            this.cbCopy.AutoSize = true;
            this.cbCopy.Location = new System.Drawing.Point(4, 308);
            this.cbCopy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbCopy.Name = "cbCopy";
            this.cbCopy.Size = new System.Drawing.Size(188, 21);
            this.cbCopy.TabIndex = 8;
            this.cbCopy.Text = "Copy files to target folder";
            this.cbCopy.UseVisualStyleBackColor = true;
            this.cbCopy.CheckedChanged += new System.EventHandler(this.cbCopy_CheckedChanged);
            // 
            // lblErToss
            // 
            this.lblErToss.AutoSize = true;
            this.lblErToss.Location = new System.Drawing.Point(7, 222);
            this.lblErToss.Name = "lblErToss";
            this.lblErToss.Size = new System.Drawing.Size(12, 17);
            this.lblErToss.TabIndex = 9;
            this.lblErToss.Text = " ";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(687, 524);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.lblErToss2);
            this.tabPage1.Controls.Add(this.lblActTar);
            this.tabPage1.Controls.Add(this.pbar2);
            this.tabPage1.Controls.Add(this.btnExit2);
            this.tabPage1.Controls.Add(this.btnGO);
            this.tabPage1.Controls.Add(this.lblTarg1);
            this.tabPage1.Controls.Add(this.lblSrc);
            this.tabPage1.Controls.Add(this.btnTarget);
            this.tabPage1.Controls.Add(this.btnSource);
            this.tabPage1.Controls.Add(this.lblNNSourceFol);
            this.tabPage1.Controls.Add(this.lblNNTarget);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(679, 495);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Target oth. Dir.";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnExit2
            // 
            this.btnExit2.Location = new System.Drawing.Point(475, 391);
            this.btnExit2.Name = "btnExit2";
            this.btnExit2.Size = new System.Drawing.Size(88, 34);
            this.btnExit2.TabIndex = 7;
            this.btnExit2.Text = "Exit";
            this.btnExit2.UseVisualStyleBackColor = true;
            this.btnExit2.Click += new System.EventHandler(this.btnExit2_Click);
            // 
            // btnGO
            // 
            this.btnGO.Location = new System.Drawing.Point(115, 391);
            this.btnGO.Name = "btnGO";
            this.btnGO.Size = new System.Drawing.Size(88, 34);
            this.btnGO.TabIndex = 6;
            this.btnGO.Text = "GO!!!";
            this.btnGO.UseVisualStyleBackColor = true;
            this.btnGO.Click += new System.EventHandler(this.btnGO_Click);
            // 
            // lblTarg1
            // 
            this.lblTarg1.AutoSize = true;
            this.lblTarg1.Location = new System.Drawing.Point(231, 80);
            this.lblTarg1.Name = "lblTarg1";
            this.lblTarg1.Size = new System.Drawing.Size(0, 17);
            this.lblTarg1.TabIndex = 5;
            // 
            // lblSrc
            // 
            this.lblSrc.AutoSize = true;
            this.lblSrc.Location = new System.Drawing.Point(231, 22);
            this.lblSrc.Name = "lblSrc";
            this.lblSrc.Size = new System.Drawing.Size(0, 17);
            this.lblSrc.TabIndex = 4;
            // 
            // btnTarget
            // 
            this.btnTarget.Location = new System.Drawing.Point(21, 71);
            this.btnTarget.Name = "btnTarget";
            this.btnTarget.Size = new System.Drawing.Size(88, 34);
            this.btnTarget.TabIndex = 3;
            this.btnTarget.Text = "Target";
            this.btnTarget.UseVisualStyleBackColor = true;
            this.btnTarget.Click += new System.EventHandler(this.btnTarget_Click);
            // 
            // btnSource
            // 
            this.btnSource.Location = new System.Drawing.Point(21, 13);
            this.btnSource.Name = "btnSource";
            this.btnSource.Size = new System.Drawing.Size(88, 34);
            this.btnSource.TabIndex = 2;
            this.btnSource.Text = "Source";
            this.btnSource.UseVisualStyleBackColor = true;
            this.btnSource.Click += new System.EventHandler(this.btnSource_Click);
            // 
            // lblNNSourceFol
            // 
            this.lblNNSourceFol.AutoSize = true;
            this.lblNNSourceFol.Location = new System.Drawing.Point(124, 22);
            this.lblNNSourceFol.Name = "lblNNSourceFol";
            this.lblNNSourceFol.Size = new System.Drawing.Size(101, 17);
            this.lblNNSourceFol.TabIndex = 1;
            this.lblNNSourceFol.Text = "Source Folder:";
            // 
            // lblNNTarget
            // 
            this.lblNNTarget.AutoSize = true;
            this.lblNNTarget.Location = new System.Drawing.Point(124, 80);
            this.lblNNTarget.Name = "lblNNTarget";
            this.lblNNTarget.Size = new System.Drawing.Size(98, 17);
            this.lblNNTarget.TabIndex = 0;
            this.lblNNTarget.Text = "Target Folder:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pbar);
            this.tabPage2.Controls.Add(this.lblErToss);
            this.tabPage2.Controls.Add(this.BtnYes);
            this.tabPage2.Controls.Add(this.cbCopy);
            this.tabPage2.Controls.Add(this.btnNo);
            this.tabPage2.Controls.Add(this.cbDelete);
            this.tabPage2.Controls.Add(this.lblNNDumpTo);
            this.tabPage2.Controls.Add(this.lblBarAction);
            this.tabPage2.Controls.Add(this.lblDirectory);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(679, 495);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Target Cur. Dir.";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pbar2
            // 
            this.pbar2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pbar2.Location = new System.Drawing.Point(36, 293);
            this.pbar2.Name = "pbar2";
            this.pbar2.Size = new System.Drawing.Size(606, 43);
            this.pbar2.TabIndex = 8;
            // 
            // lblActTar
            // 
            this.lblActTar.AutoSize = true;
            this.lblActTar.Location = new System.Drawing.Point(33, 258);
            this.lblActTar.Name = "lblActTar";
            this.lblActTar.Size = new System.Drawing.Size(98, 17);
            this.lblActTar.TabIndex = 9;
            this.lblActTar.Text = "Target Folder:";
            // 
            // lblErToss2
            // 
            this.lblErToss2.AutoSize = true;
            this.lblErToss2.Location = new System.Drawing.Point(33, 356);
            this.lblErToss2.Name = "lblErToss2";
            this.lblErToss2.Size = new System.Drawing.Size(0, 17);
            this.lblErToss2.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RBCopy);
            this.groupBox1.Controls.Add(this.RBMove);
            this.groupBox1.Location = new System.Drawing.Point(21, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(275, 96);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "What to do with these files:";
            // 
            // RBMove
            // 
            this.RBMove.AutoSize = true;
            this.RBMove.Checked = true;
            this.RBMove.Location = new System.Drawing.Point(15, 31);
            this.RBMove.Name = "RBMove";
            this.RBMove.Size = new System.Drawing.Size(239, 21);
            this.RBMove.TabIndex = 0;
            this.RBMove.TabStop = true;
            this.RBMove.Text = "Move files from Source => Target";
            this.RBMove.UseVisualStyleBackColor = true;
            // 
            // RBCopy
            // 
            this.RBCopy.AutoSize = true;
            this.RBCopy.Location = new System.Drawing.Point(15, 67);
            this.RBCopy.Name = "RBCopy";
            this.RBCopy.Size = new System.Drawing.Size(237, 21);
            this.RBCopy.TabIndex = 1;
            this.RBCopy.TabStop = true;
            this.RBCopy.Text = "Copy files from Source => Target";
            this.RBCopy.UseVisualStyleBackColor = true;
            // 
            // LAnorexia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 538);
            this.Controls.Add(this.tabControl1);
            this.Name = "LAnorexia";
            this.Text = "Wanorexia";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnYes;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Label lblNNDumpTo;
        private System.Windows.Forms.Label lblDirectory;
        private System.Windows.Forms.ProgressBar pbar;
        private System.Windows.Forms.Label lblBarAction;
        private System.Windows.Forms.CheckBox cbDelete;
        private System.Windows.Forms.CheckBox cbCopy;
        private System.Windows.Forms.Label lblErToss;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblNNSourceFol;
        private System.Windows.Forms.Label lblNNTarget;
        private System.Windows.Forms.Label lblTarg1;
        private System.Windows.Forms.Label lblSrc;
        private System.Windows.Forms.Button btnTarget;
        private System.Windows.Forms.Button btnSource;
        private System.Windows.Forms.Button btnExit2;
        private System.Windows.Forms.Button btnGO;
        private System.Windows.Forms.ProgressBar pbar2;
        private System.Windows.Forms.Label lblActTar;
        private System.Windows.Forms.Label lblErToss2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RBCopy;
        private System.Windows.Forms.RadioButton RBMove;
    }
}

