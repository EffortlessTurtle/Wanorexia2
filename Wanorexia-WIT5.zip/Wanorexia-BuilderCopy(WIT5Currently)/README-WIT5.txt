//THis is a production of EffortlessTurtle
//EffortlessTurtle == Tyler Shrouder
//Copyright 2017 Tyler Shrouder, Raymond Tresner
//Released under GPL   
//For Wanorexia-WIT5 (Wanorexia - Working iteration version 5)
//05AUG2017

This was written in C# using VisualStudio (VS) 2015. I do not plan to use VS 2017.

Suggestions or Hints:
If you have either of these, please contact the designers at anangryfurby.69@yahoo.com. Please place the name of the file you are using in the subject line (i.e."Wanorexia-WIT5").
+++++ANY EMAIL WITH UNSOLICITED ATTACHMENTS WILL -NOT- BE READ+++

History:
There was a guy who approached us and he needed an application(utility) made to recursively move a parent directory's child directories to one folder for Windows 10. Essentially, consolidate all files in child directories contained in a parent directory's full structure into one folder. The Wanorexia name is due to the designers' sick sense of humor and is in no way saying that the disease Anorexia is a trivial thing.

Testing:
This tool has a very small beta tester set. We have roughly 5 testers right now. We have not tested the C:/ drive kill switch, nor do we plan too. This little baby moves very fast. If there is a problem you wish for us to fix please see the 'Suggestions or Hints' Section for the email. Use the same subject line convention just add '-error' to the end of the line(i.e."Wanorexia-WIT5-error"). Describe in text as best you can what you were doing and how the program broke. Any exception errors thrown will be greatly helpful in troubleshooting.

Under The Hood:
What this does is recursively move or Copy the files in the child directories to a folder called 'A1-Purged' while preserving the directory structure. Due to the way MS Windows 10 organizes folders, this ensures that the purged folder is always first or last on the list. this does depend on how the folders are filtered by the user. The default is to move the files, also there is a copy files option. This iteration requires a user to place Wanorexia.exe into the parent directory they wish to consolidate. Later iterations will have a way to choose the source and target directories. For other changes on the TODO list see the section below.

Things On the TODO List:
-Find a way to change folder source and target
-Find a way to filter for only files wanted
-Find a way to make folders for selected file types
-MAKE The UI PRETTIER
-Finding a way to make the form window persistant until transfers are complete<<Researching Modal Forms right now>>


Rick Roll:
https://www.youtube.com/watch?v=dQw4w9WgXcQ

